clear
toilet -f slant --gay "INSTALLING"
pkg upgrade;pkg update;pkg install python2;pip2 install bs4;pip2 install requests;pip2 install mechanize;pkg install openssh;pkg install php;pkg install figlet;pkg install ruby;pkg install wget;apt install python2-dev;apt instal git php curl -y;apt install python3 python3-pip;pip3 install requests
toilet -f slant --gay "DONE"
