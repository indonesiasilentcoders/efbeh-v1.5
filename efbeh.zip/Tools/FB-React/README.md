
# FB-React

git clone it <br>
masuk direktori <br>
chmod 777 start <br>
./start
