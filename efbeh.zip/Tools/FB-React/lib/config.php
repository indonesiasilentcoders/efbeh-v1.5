<?php
$user = "";
$pass = "";
$r_male = "8";
$r_female = "8";
$max_status = "100";
?>