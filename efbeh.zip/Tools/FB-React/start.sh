#!/data/data/com.termux/files/usr/bin/bash
# Recorde Lu Ya Ngentod
# by Asano魔

black='\033[1;30m'
red='\033[1;31m'
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
cyan='\033[1;36m'
white='\033[1;37m'


echo  $blue"   _______    ___               __  ";
echo  $blue"  / __/ _ )  / _ \___ ___ _____/ /_ ";
echo  $blue" / _// _ |  / , _/ -_) _  / __/ __/ ";
echo  $blue"/_/ /____/ /_/|_|\__/\_,_/\__/\__/"$red"v1.5";
echo  $red"              Modified by ./Asano ";
echo  $green" Thanks to: ";
echo  $green" { Indonesia Silent Coders } ";
echo  $white"\n";
sleep 1
echo "[ 1 ] Input Nomor 1 Jika Kamu Belum Install Bahan²";
echo "[ 2 ] Input Nomor 2 Jika Sudah Langsung Gaskeun Lah Ajg";
echo "[ 3 ] Exit/Keluar";
read -p "[ ./Asano ] >"  act;

if [ $act = 1 ] || [ $act = 1 ]
then
apt update -y && apt upgrade -y
pkg install -y php
clear
sleep 1
php 1.php
clear
php 2.php
sleep 2
clear
php 3.php
fi

if [ $act = 2 ] || [ $act = 2 ]
then
clear
php 1.php
clear
php 2.php
sleep 2
clear
php 3.php
fi

if [ $act = 3 ] || [ $act = 3 ]
then
echo $red'untuk kamu para pemula'
sleep 1
echo  $red'jangan berhenti mencari ilmu'
sleep 1
echo  $red'karna ilmu tidak ada habisnya'
sleep 1
echo  $red'sekian dari gua'
sleep 1
echo  $cyan'./Asano '
sleep 1
exit
fi
