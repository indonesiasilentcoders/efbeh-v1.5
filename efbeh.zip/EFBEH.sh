#!/system/xbin/bash
#ngapain lu bangsat
#mau recorde?
#Gak bakal jadiin lu mastah Kampang
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#colors
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
indigo="\033[34;1m"
clear
echo "Asslamualaikum Wr Wb"
sleep 1
echo "Gunakan Seperlunya Dosa Tanggung Sendiri :v"
sleep 2
clear
echo $cyan "       __________"$red"    v1.5  "
echo $cyan "      |          \               "
echo $cyan "      |  ________|_              "
echo $cyan "      |  |       |  \            "
echo $cyan "      |  |_____  |  |            "
echo $cyan "      |   _____| |  |___         "
echo $cyan "      |  |       |   _  \        "
echo $cyan "      |  |       |  |_| |        "
echo $cyan "      | /        \______/        "
echo $white"     Facebook Hacking Tools™     "
echo $red  " Copyright © 2019 Salman Wahib   "
echo ""
echo $blue "-------------[MENU]-------------"
echo $cyan "[ 1 ] Multi BruteForce Facebook"
echo $cyan "[ 2 ] BruteForce Facebook Target"
echo $cyan "[ 3 ] Auto Report Facebook Target"
echo $cyan "[ 4 ] Shell Foto Profil Facebook"$red" New"
echo $cyan "[ 5 ] Auto Like & React Bot Facebook"$red" New"
echo $cyan "[ 6 ] List ID MBF"
echo $cyan "[ 7 ] List Password BFT"
echo $cyan "[ 9 ] Info"
echo $cyan "[ 0 ] Exit/Keluar"
echo ""
echo $cyan"╭─./Asano"
read -p "╰─‚シ’ " kampang

if [ $kampang = "0" ] || [ $kampang = "00" ]
then
echo $cyan
clear
toilet -f slant --gay "EXIT"
echo $white "Terimakasi telah menggunakan tools kami semoga berfaedah kampang :)"
sleep 1
exit
fi

if [ $kampang = "01" ] || [ $kampang = "1" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
cd Tools
python2 MBF.py
fi

if [ $kampang = "02" ] || [ $kampang = "2" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
cd Tools
python2 fbbrute.py
fi

if [ $kampang = "03" ] || [ $kampang = "3" ]
then
toilet -f future -F gay W E L C O M E
sleep 1
cd Tools
cd Report
python2 Report.py
fi

if [ $kampang = "04" ] || [ $kampang = "4" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
cd Tools
cd guardn
python3 guardn.py
fi

if [ $kampang = "05" ] || [ $kampang = "5" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
cd Tools
cd FB-React
chmod +x start.sh
sh start.sh
fi

if [ $kampang = "09" ] || [ $kampang = "9" ]
then
clear
toilet -f future -F gay I N F O
echo""
echo $cyan   "Author : ./Asano / Salman Wahib"
echo $cyan   "Email  : asanoyuzumi@gmail.com"
echo $cyan   "Team   : { Indonesia Silent Coders }"
echo $cyan   "Contact: 089686887867"
echo $red    "-----------Version 1.5-------------"
echo""
echo $cyan   "   –=Special Thank=–"
echo $cyan   "PIRMANSX - IndoSecHacker"
echo $green
echo "╭─[B]:Back [E]:Exit "
echo "|"$red
read -p "╰─[B]/[E] :" kontol
fi

if [ $kontol = "B" ] || [ $kontol = "b" ]
then
clear
sh EFBEH.sh
fi
if [ $kontol = "E" ] || [ $kontol = "e" ]
then
echo $cyan
clear
toilet -f slant --gay "EXIT"
echo $white "Terimakasi telah menggunakan tools kami semoga berfaedah kampang :)"
sleep 1
exit
fi

if [ $kampang = "06" ] || [ $kampang = "6" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
clear
cd Tools
nano id.txt
fi

if [ $kampang = "07" ] || [ $kampang = "7" ]
then
clear
toilet -f future -F gay W E L C O M E
sleep 1
clear
cd Tools
nano password.txt
fi
